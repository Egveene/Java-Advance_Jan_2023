package T05_06_Multydimentional_Arrays.Lab;

import java.util.Scanner;

public class P04_Sum_Matrix_Elements {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

}
}
