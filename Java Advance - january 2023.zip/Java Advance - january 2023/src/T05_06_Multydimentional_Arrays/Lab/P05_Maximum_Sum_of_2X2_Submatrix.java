package T05_06_Multydimentional_Arrays.Lab;

import java.util.Scanner;

public class P05_Maximum_Sum_of_2X2_Submatrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}

