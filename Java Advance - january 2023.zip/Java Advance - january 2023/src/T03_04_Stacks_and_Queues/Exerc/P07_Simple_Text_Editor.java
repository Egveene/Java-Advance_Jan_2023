package T03_04_Stacks_and_Queues.Exerc;

import java.util.ArrayDeque;
import java.util.Scanner;

public class P07_Simple_Text_Editor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        for (int commandNumber = 1; commandNumber <= n; commandNumber++) {
            String command = scanner.nextLine();
            StringBuilder currentText = new StringBuilder();
            ArrayDeque<String> textSteck = new ArrayDeque<>();
            if (command.startsWith("1")) {
                textSteck.push(currentText.toString());
                String textToAppend = command.split("\\s+")[2];
                currentText.append(textToAppend);
            } else if (command.startsWith("2")) {
                textSteck.push(currentText.toString());
                int count = Integer.parseInt(command.split(" ")[1]);
                int startIndexForDelete = currentText.length() - count;
                currentText.delete(startIndexForDelete, currentText.length());
            } else if (command.startsWith("3")) {
                int position = Integer.parseInt(command.split("\\s+")[1]);
                System.out.println(currentText.charAt(position - 1));
            } else if (command.equals("4")) {
                if (!textSteck.isEmpty()) {
                    String last = textSteck.pop();
                    currentText = new StringBuilder(last);
                }
            }
        }

    }
}
