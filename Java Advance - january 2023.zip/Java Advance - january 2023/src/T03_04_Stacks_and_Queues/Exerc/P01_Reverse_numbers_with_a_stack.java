package T03_04_Stacks_and_Queues.Exerc;


import java.util.ArrayDeque;
import java.util.Scanner;

public class P01_Reverse_numbers_with_a_stack {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        ArrayDeque<Integer> reverceNumbers = new ArrayDeque<>();
        for (int i = input.length()-1 ; i <= 0 ; i--) {
            int number = Integer.parseInt(input.split(" ")[i]);
            reverceNumbers.push(number);
        }


    }
}
