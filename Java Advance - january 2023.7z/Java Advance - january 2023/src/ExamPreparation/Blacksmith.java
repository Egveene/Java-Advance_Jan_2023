package ExamPreparation;
//13-04-2022-P01 E

import java.util.*;
import java.util.stream.Collectors;


public class Blacksmith {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> steelList = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).collect(Collectors.toList());
        List<Integer> carboneList = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).collect(Collectors.toList());


        Deque<Integer> steelDeque = new ArrayDeque<>();
        ArrayDeque<Integer> carboneStack = new ArrayDeque<>();
        HashMap<Integer, String> swordsInfo = new HashMap<>();
        mapSwords(swordsInfo);


        for (int element : steelList) {
            steelDeque.offer(element);
        }
        for (int element : carboneList) {
            carboneStack.push(element);
        }


        while (!steelDeque.isEmpty() || !carboneStack.isEmpty()) {
            int sumCompounts = steelDeque.peek() + carboneStack.peek();

            if (swordsInfo.containsKey(sumCompounts)) {
                String currentSword = swordsInfo.get(sumCompounts);

                steelDeque.pop();
                int currentCarbonElement = carboneStack.pop() + 5;
                carboneStack.offer(currentCarbonElement);

            } else {

            }
        }
    }

    private static void mapSwords(HashMap<Integer, String> swordsInfo) {
        swordsInfo.put(70, "Gladius");
        swordsInfo.put(80, "Shamshir");
        swordsInfo.put(90, "Katana");
        swordsInfo.put(110, "Sabre");
    }
}
