package MultydimentionalArrays02;

public class Demo {
}
