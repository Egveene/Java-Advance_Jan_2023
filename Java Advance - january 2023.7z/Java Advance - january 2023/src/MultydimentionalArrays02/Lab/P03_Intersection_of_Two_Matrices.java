package MultydimentionalArrays02.Lab;

import java.util.Scanner;

public class P03_Intersection_of_Two_Matrices {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
