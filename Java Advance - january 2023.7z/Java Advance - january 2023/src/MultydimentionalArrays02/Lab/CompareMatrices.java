package MultydimentionalArrays02.Lab;

import java.util.Scanner;

public class CompareMatrices {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] inputDimentions = scanner.nextLine().split(" ");
        int firstRows = Integer.parseInt(inputDimentions[0]);
        int firstCols = Integer.parseInt(inputDimentions[1]);

        for (int rows = 0; rows <firstRows ; rows++) {
            String [] currentRow = scanner.nextLine().split(" ");
            for (int cols = 0; cols < firstCols; cols++) {
                String[][] firstMatrix = new String[rows][];
            }
        }
    }
}
