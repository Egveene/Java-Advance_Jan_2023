package MultydimentionalArrays02.Lab;

import java.util.Scanner;

public class P08_Wrong_Measurements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}

