package MultydimentionalArrays02.Exerc;

import java.util.Scanner;

public class P06_String_Matrix_rotation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        int rotationDegree = Integer.parseInt(input.substring(7, input.length() - 1));


    }

}
