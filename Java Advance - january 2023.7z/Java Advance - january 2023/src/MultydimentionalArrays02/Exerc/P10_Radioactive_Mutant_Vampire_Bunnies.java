package MultydimentionalArrays02.Exerc;
//*
public class P10_Radioactive_Mutant_Vampire_Bunnies {
}
