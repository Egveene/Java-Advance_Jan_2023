package MultydimentionalArrays02.Exerc;

import java.util.Scanner;

public class P04_Maximal_Sum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int rows = scanner.nextInt();
        int cols = scanner.nextInt();

        int matrixMain[][] = new int[rows][cols];
        fillingTheMatrics(matrixMain, scanner);

        int maxSum = Integer.MIN_VALUE;
        int startRow = 0;
        int startCol = 0;
        for (int row = 0; row < rows - 2; row++) {
            for (int col = 0; col < cols - 2; col++) {
                int sum = matrixMain[row][col] + matrixMain[row][col + 1] + matrixMain[row][col + 2]
                        + matrixMain[row + 1][col] + matrixMain[row + 1][col + 1] + matrixMain[row + 1][col + 2]
                        + matrixMain[row + 2][col] + matrixMain[row + 2][col + 1] + matrixMain[row + 2][col + 2];

                if (sum > maxSum) {
                    maxSum = sum;
                    startRow = row;
                    startCol = col;
                }
            }

        }

        System.out.println("Sum = " + maxSum);
        for (int row = startRow; row <= startRow + 2; row++) {
            for (int col = startCol; col <= startCol + 2; col++) {
                System.out.print(matrixMain[row][col] + " ");
            }
            System.out.println();
        }


    }

    private static void printMatrix(String[][] matrix) {
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println();
        }
    }

    private static void fillingTheMatrics(int[][] matrixMain, Scanner scanner) {
        for (int rols = 0; rols < matrixMain.length; rols++) {
            for (int cols = 0; cols <= matrixMain.length; cols++) {
                int elementOfMatrix = scanner.nextInt();
                matrixMain[rols][cols] = elementOfMatrix;
            }
        }

    }

}
