package MultydimentionalArrays02.Exerc;

import java.util.Scanner;

public class P04_Maximal_Sum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //1.прочетем входните данни- колко реда колко колони ще има
        //2.напълним една матрица с М редове и Н колкони.
        //Трябва да направим 2 метода.Един,който изчислява максималната сума от елементите на матрица 3х3(като вземем от матрицата майка) и втори,който я принтира.
        int rows = scanner.nextInt();
        int cols = scanner.nextInt();
        int sum = 0;

        int[][] matrixMain = new int[rows][cols];
        fillingTheMatrics(matrixMain, scanner);

        int currentRols = 3;
        int currentCols = 3;
        int sumMatrics = 0;
        while(!(currentRols>=rows) && !(currentCols>=cols)){
            int currentSum = 0;
            for (int row = 0; row < currentRols; row++) {
                for (int col = 0; col < currentCols; col++) {
                    currentSum+=matrixMain[row][col];
                }
            }
           
            currentCols++;
            currentRols++;
        }



    }



    private static void fillingTheMatrics(int[][] matrixMain, Scanner scanner) {
        for (int rols = 0; rols < matrixMain.length; rols++) {
            for (int cols = 0; cols <= matrixMain.length; cols++) {
                int elementOfMatrix = scanner.nextInt();
                matrixMain[rols][cols] = elementOfMatrix;
            }
        }

    }

}
