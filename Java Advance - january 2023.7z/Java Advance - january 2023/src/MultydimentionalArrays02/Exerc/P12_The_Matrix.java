package MultydimentionalArrays02.Exerc;
//*
public class P12_The_Matrix {
}
