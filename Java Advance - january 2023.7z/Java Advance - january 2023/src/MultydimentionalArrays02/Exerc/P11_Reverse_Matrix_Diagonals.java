package MultydimentionalArrays02.Exerc;

public class P11_Reverse_Matrix_Diagonals {
}
