package T05_06_Multydimentional_Arrays.Exerc;

public class P11_Reverse_Matrix_Diagonals {
}
