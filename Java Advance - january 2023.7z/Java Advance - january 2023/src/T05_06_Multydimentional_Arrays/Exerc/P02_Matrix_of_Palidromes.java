package T05_06_Multydimentional_Arrays.Exerc;

import java.util.Scanner;

public class P02_Matrix_of_Palidromes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
