package T05_06_Multydimentional_Arrays.Exerc;

public class P12_The_Matrix {
}
