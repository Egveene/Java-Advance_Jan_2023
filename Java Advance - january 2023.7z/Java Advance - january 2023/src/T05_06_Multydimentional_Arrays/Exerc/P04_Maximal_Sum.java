package T05_06_Multydimentional_Arrays.Exerc;

public class P04_Maximal_Sum {
}
