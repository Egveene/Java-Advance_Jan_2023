package T05_06_Multydimentional_Arrays.Exerc;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.util.Scanner;

public class P01_Fill_the_Matrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        int n = Integer.parseInt(input.split(", ")[0]);
         String pattern =input.split(", ")[1];

         int [][] matrix = new int[n][n];
         if (pattern.equals("A")){


         } else if (pattern.equals("B")) {

         }
    }
    private static void fillMatrixPatternA(int[][] matrix){
        for (int col = 0; col < matrix.length; col++) {
            for (int row = 0; row < matrix.length; row++) {

            }
        }
    }
    public static void fillMatrix (int [][] matrix){

    }
}
