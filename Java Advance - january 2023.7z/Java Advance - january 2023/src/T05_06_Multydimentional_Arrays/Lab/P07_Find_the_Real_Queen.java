package T05_06_Multydimentional_Arrays.Lab;

import java.util.Scanner;

public class P07_Find_the_Real_Queen {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}

