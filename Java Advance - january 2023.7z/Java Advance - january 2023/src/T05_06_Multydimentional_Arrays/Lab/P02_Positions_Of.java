package T05_06_Multydimentional_Arrays.Lab;

import java.util.Scanner;

public class P02_Positions_Of {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String [] rowsAndCol =  scanner.nextLine().split(" ");
        int rows = Integer.parseInt(rowsAndCol[0]);
        int col = Integer.parseInt(rowsAndCol[1]);

        int[][] matrix = new  int[rows][col];


    }
}

