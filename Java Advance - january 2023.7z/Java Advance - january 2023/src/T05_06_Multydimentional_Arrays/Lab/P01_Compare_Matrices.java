package T05_06_Multydimentional_Arrays.Lab;

import java.util.Scanner;

public class P01_Compare_Matrices {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] inputDimentions = scanner.nextLine().split(" ");
        int firstRows = Integer.parseInt(inputDimentions[0]);
        int firstCols = Integer.parseInt(inputDimentions[1]);

        int[][] firstMatrix = new int[firstRows][firstCols];
        for (int i = 0; i < firstRows; i++) {
            String[] part = scanner.nextLine().split(" ");
            for (int j = 0; j < firstCols; j++) {
                firstMatrix[i][j] = Integer.parseInt(part[j]);
            }
        }
        inputDimentions = scanner.nextLine().split(" ");

    }
}
