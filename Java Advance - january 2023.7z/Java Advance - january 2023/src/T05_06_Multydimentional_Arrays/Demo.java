package T05_06_Multydimentional_Arrays;

public class Demo {
}
