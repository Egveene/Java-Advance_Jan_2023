package SetAndMaps03.exec;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class P08_User_Log {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
      TreeMap<String, LinkedHashMap<String,Integer>> data = new TreeMap<>();
        String input = scanner.nextLine();


        while(!input.equals("end")){
            String ip = input.split("\\s+")[0].split("=")[1];
            String messege = input.split("\\s+")[1].split("=")[1];
            String username = input.split("\\s+")[2].split("=")[1];
            if(!data.containsKey(username)){
                data.put(username,new LinkedHashMap<>());
            }
                Map<String,Integer>currentIp = data.get(username);
           if(currentIp.containsKey(ip)){
               currentIp.put(ip,1);
           }else {
               currentIp.put(ip,currentIp.get(ip)+1);
           }
            input = scanner.nextLine();
        }


    }
}
