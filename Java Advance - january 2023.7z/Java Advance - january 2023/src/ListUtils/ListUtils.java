package ListUtils;

import java.util.List;

public class ListUtils {

    // T getMin(List<T> list)


    }
    //T getMax(List<T> list)



