package StreamsFilesAndDirectories04.lab;


import java.io.FileInputStream;
import java.io.IOException;

import java.io.InputStream;
import java.util.Scanner;

public class P01
{
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        String filePath = "C:\\Users\\iliyanaPC\\Desktop\\JAVA\\Java Advance\\09&10_Streams,Files and Directories\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";

    InputStream inputStream = new FileInputStream(filePath);
        int firstBite = inputStream.read();
        System.out.print(firstBite);
        System.out.println((char)firstBite);

        inputStream.close();

    }
}
