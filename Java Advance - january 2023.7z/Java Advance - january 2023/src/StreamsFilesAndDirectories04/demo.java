package StreamsFilesAndDirectories04;

public class demo {
}
