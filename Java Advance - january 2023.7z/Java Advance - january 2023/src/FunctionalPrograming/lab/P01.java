package FunctionalPrograming.lab;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class P01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> numbers = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());


        numbers.removeIf(num -> num % 2 != 0);
        numbers.forEach(num -> System.out.println(num));
        System.out.println();
        numbers
                .stream()
                .sorted()
                .forEach(num -> System.out.print(num + " "));
        for (int number:
             numbers) {
            System.out.print(number + " ");
        }
    }
}
