package FunctionalPrograming;

public class Demo {
    public static void main(String[] args) {
        //Function - приема някакъв параметър и връща някакъв параметър- активира се чрез метода apply

        //Consumer - Приема само 1 параметър и трябва да мъ зададем типа на входа.Той е като void - не връща резултат -aktivira se chrez accept

        //Suplier - Активира се с get
        //Predicate - булева стойност връща true/false - aktiwira se s Test
        //BiFunction - Приема 2 параметъра - като Фунцтион - apply

    }
}
