package StacksAndQueues01.Exerc;

import java.util.Scanner;

public class P07_Simple_Text_Editor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countOperations = Integer.parseInt(scanner.nextLine());
        for (int oprations = 1; oprations <=countOperations; oprations++) {
            String command = scanner.nextLine();
            switch (command.split(" ")[0]){
                case"1": break;
                case"2": break;
                case"3": break;
                case"4":break;
            }
        }


    }
}
