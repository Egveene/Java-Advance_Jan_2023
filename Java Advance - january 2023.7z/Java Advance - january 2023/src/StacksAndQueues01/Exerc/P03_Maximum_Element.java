package StacksAndQueues01.Exerc;

import java.util.ArrayDeque;
import java.util.Scanner;

public class P03_Maximum_Element {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //1-> число,което ще бъде броя команди,който ще се подадат по-нататък
        //2-> Тип команди:
        // "1 X" - Push the element X into the stack.
        // "2" - Delete the element present at the top of the stack.
        // "3" - Print the maximum element in the stack.
        int numOfCommands = Integer.parseInt(scanner.nextLine());
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        for (int i = 1; i <= numOfCommands; i++) {
            String comamnd = scanner.nextLine();
            switch (comamnd.split("\\s+")[0]) {
                case "1":
                    int elementPush = Integer.parseInt(comamnd.split("\\s+")[1]);
                    stack.push(elementPush);
                    break;
                case "2":
                    if (!stack.isEmpty()){
                        stack.pop();
                    }
                    break;
                case "3":
                 int maxElement =0;
                 maxElement = maxElement(stack,maxElement);
                    System.out.println(maxElement);
                    break;
            }
        }
    }
    public static int maxElement (ArrayDeque<Integer> stack,int maxElement){
        for (int element:
             stack) {
            if(element>maxElement){
                maxElement = element;
            }
        }
        return maxElement;
    }

}
