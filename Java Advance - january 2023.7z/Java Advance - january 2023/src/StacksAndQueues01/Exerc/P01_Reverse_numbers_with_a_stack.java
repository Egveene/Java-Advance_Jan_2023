package StacksAndQueues01.Exerc;


import java.util.ArrayDeque;
import java.util.Scanner;

public class P01_Reverse_numbers_with_a_stack {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        ArrayDeque<Integer> numbers = new ArrayDeque<>();
        String[] numberArr = input.split(" ");
        for (int i = 0; i < numberArr.length; i++) {
            int number = Integer.parseInt(numberArr[i]);
            numbers.push(number);
        }
        for (int num:
             numbers) {
            System.out.print(numbers.pop() + " ");
        }

    }
}
