package StacksAndQueues01.Exerc;

public class P10__ {
}
