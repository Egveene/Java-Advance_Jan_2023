package StacksAndQueues01.Lab;

import java.util.ArrayDeque;
import java.util.Scanner;

public class P05_Printer_Queue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayDeque<String> queue = new ArrayDeque<>();
        String currentInput = scanner.nextLine();
        while (true) {
            switch (currentInput) {
                case "print":
                    for (String doc:queue) {
                        System.out.println(doc);
                    }
                    return;
                case "cancel":
                    if(queue.isEmpty()){
                        System.out.println("Printer is on standby");
                    }else {
                    System.out.printf("Canceled %s%n", queue.pollFirst());
                    }
                    break;
                default:
                    queue.offer(currentInput);
                    break;
            }
            currentInput = scanner.nextLine();
        }
    }
}



