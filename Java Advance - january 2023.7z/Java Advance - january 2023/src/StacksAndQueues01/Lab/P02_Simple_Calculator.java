package StacksAndQueues01.Lab;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class P02_Simple_Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayDeque<String> stack = new ArrayDeque<>();
        String expression = scanner.nextLine();
        String[] exxpretionsParts = expression.split(" ");
        List<String> partsList = Arrays.asList(exxpretionsParts);

        Collections.reverse(partsList);


        for (String part :
                partsList) {
            stack.push(part);
        }
        while (stack.size() > 1) {
            int first = Integer.parseInt(stack.pop());
            String op = stack.pop();
            int second = Integer.parseInt(stack.pop());

            int result;
            switch (op) {
                case "+":
                    result = first + second;
                    break;
                case "-":
                    result = first - second;
                    break;
                default:
                    System.out.println("Unknown operation " + op);
                    return;
            }
            stack.push("" + result);

        }
        System.out.println(stack.peek());

    }
}
