package GenericScale;

public class Scale<T extends Comparable<T>> {
    private T left;
    private T rigth;

    public Scale(T left, T rigth) {
        this.left = left;
        this.rigth = rigth;
    }
    public T getHeavier(){
        if(left.compareTo(rigth)<0){
            return rigth;
        }
        if(left.compareTo(rigth)>0){
            return left;
        }
        return null;
    }
}
