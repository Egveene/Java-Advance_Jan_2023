package GenericArrayCreator;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ArrayCreator {
    public static <T> List<T> create(int length, T item){
      List<T> array = new ArrayList<>();
        for (int i = 0; i < length; i++) {
            array.add(item);
        }
        return array;
    }
    public static <T> T [] create(Class<T> tClass,int length, T item){
        T[] array = (T[]) Array.newInstance(tClass,length);
        for (int i = 0; i < length; i++) {
            array[i] = item;
        }
        return array;
    }
}
