package JAR;

import java.util.ArrayList;
import java.util.List;

public class JArOfPickles extends Jar<Pickle>{
    public JArOfPickles(List<Pickle> items) {
        this.items = new ArrayList<>();
    }
    private List<Pickle> items;
        public void  addItem(Pickle item){
            this.items.add(item);
        }


}
