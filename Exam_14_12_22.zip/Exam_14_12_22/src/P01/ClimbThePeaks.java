package P01;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ClimbThePeaks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> foodSuply = Arrays.stream(scanner.nextLine().split(", ")).map(Integer::parseInt).collect(Collectors.toList());
        List<Integer> stamina = Arrays.stream(scanner.nextLine().split(", ")).map(Integer::parseInt).collect(Collectors.toList());

        ArrayDeque<Integer> foodPortions = new ArrayDeque<>();
        fillingTheSteakDeque(foodSuply, foodPortions);

        Deque<Integer> dailyStamina = new ArrayDeque<>();
        fillingTheDeque(stamina, dailyStamina);

        Map<Integer, String> mountainDifficultyLevel = new LinkedHashMap<>();
        mountainDifficultyLevel.put(80, "Vihren");
        mountainDifficultyLevel.put(90, "Kutelo");
        mountainDifficultyLevel.put(100, "Banski Suhodol");
        mountainDifficultyLevel.put(60, "Polezhan");
        mountainDifficultyLevel.put(70, "Kamenitza");

        StringBuilder conquerPeeks = new StringBuilder();

        int counter = 1;
        int sumFoodSuplies = 0;
        while (counter <= 7 && !(foodPortions.isEmpty()) && !(dailyStamina.isEmpty())) {

            sumFoodSuplies = foodPortions.pop() + dailyStamina.pollFirst();
            if (!(mountainDifficultyLevel.isEmpty())) {
                if (mountainDifficultyLevel.containsKey(sumFoodSuplies)) {
                    conquerPeeks.append((mountainDifficultyLevel.remove(sumFoodSuplies)).toString() + "\n");
                }
                counter++;
            }
        }
        if (mountainDifficultyLevel.isEmpty()) {
            System.out.println("Alex did it! He climbed all top five Pirin peaks in one week -> @FIVEinAWEEK");
            System.out.println("Conquered peaks:");
            System.out.println(conquerPeeks);

        } else {
            System.out.println("Alex failed! He has to organize his journey better next time -> @PIRINWINS");
        }

    }


    private static ArrayDeque<Integer> fillingTheSteakDeque(List<Integer> input, ArrayDeque<Integer> steakDeque) {

        for (int element : input) {
            steakDeque.push(element);
        }
        return steakDeque;
    }

    private static Deque<Integer> fillingTheDeque(List<Integer> input, Deque<Integer> deque) {

        for (int element : input) {
            deque.offer(element);
        }
        return deque;
    }
}