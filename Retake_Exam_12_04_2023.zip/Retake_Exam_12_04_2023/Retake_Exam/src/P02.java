import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class P02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sizeOfField = Integer.parseInt(scanner.nextLine());
        String[] command = scanner.nextLine().split(", ");
        String[][] matrix = new String[sizeOfField][sizeOfField];
        fillMatrix(matrix, scanner);

        List<Integer> start = new ArrayList<Integer>();
        findindSquirelPoz(matrix, start);
        int startRow = start.get(0);
        int startCol = start.get(1);
        int hazelnutsCounter = 0;
        boolean isTrap = false;
        boolean isOut = false;


        int currentRow = startRow;
        int currentCol = startCol;
        String currentPosition = matrix[currentRow][currentCol];
        for (int i = 0; i < command.length; i++) {
            String currentComand = command[i];

            switch (currentComand) {
                case "up":
                    currentRow--;
                    break;
                case "down":
                    currentRow++;
                    break;
                case "left":
                    currentCol--;
                    break;
                case "right":
                    currentCol++;
                    break;
            }
           if (isInField(matrix,currentRow,currentCol)){
               currentPosition = matrix[currentRow][currentCol];
           }else {
               isOut = true;
               break;
           }

            if (currentPosition.equals("h")) {
                hazelnutsCounter++;
                matrix[currentRow][currentCol] = "*";
                if (hazelnutsCounter == 3) {
                    break;
                }
            } else if (currentPosition.equals("t")) {
                isTrap = true;
                break;
            }
        }

        if(hazelnutsCounter == 3){
            System.out.println("Good job! You have collected all hazelnuts!");
            System.out.printf("Hazelnuts collected: %d",hazelnutsCounter);
        } else if (isTrap) {
            System.out.println("Unfortunately, the squirrel stepped on a trap...");
            System.out.printf("Hazelnuts collected: %d",hazelnutsCounter);

        } else if (isOut) {
            System.out.println("The squirrel is out of the field.");
            System.out.printf("Hazelnuts collected: %d",hazelnutsCounter);
        }else {
            System.out.println("There are more hazelnuts to collect.");
            System.out.printf("Hazelnuts collected: %d",hazelnutsCounter);
        }

    }

    private static boolean isInField(String[][] matrix, int row, int column) {
        return (row >= 0 && row < matrix.length && column >= 0 && column < matrix[row].length);
    }

    private static void findindSquirelPoz(String[][] matrix, List<Integer> start) {
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[row].length; col++) {
                if (matrix[row][col].equals("s")) {
                    start.add(row);
                    start.add(col);
                }
            }

        }

    }

    private static void fillMatrix(String[][] matrix, Scanner scanner) {
        for (int row = 0; row < matrix.length; row++) {
            matrix[row] = scanner.nextLine().split("");
        }
    }

}
