package magazine;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class Magazine {
    private String type;
    private int capacity;
    private List<Cloth> data;
    private Cloth cloth;

    public Magazine(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public void addCloth(Cloth cloth) {
        if (data.size() < this.capacity) {
            data.add(cloth);
        }
    }

    public boolean removeCloth(String color) {
        data.remove(color);
        return false;
    }

    public Cloth getSmallestCloth() {
       //Product: jeans with size 32, color blue;
       return data.stream().sorted(Comparator.comparing(Cloth::getSize).thenComparing(Cloth::getColor)).findFirst().orElse(null);
    }

    public String getCloth(String color) {
        return  data.stream().sorted(Comparator.comparing(Cloth::getColor)).findFirst().orElse(null).toString();
    }

    public int getCount() {
        return data.size();
    }

    public String report() {
        StringBuilder report = new StringBuilder();
        for (Cloth cloth : data) {
            report.append(cloth + "\n");
        }
        return String.format("%s magazine contains:"
                + report);
    }
}
