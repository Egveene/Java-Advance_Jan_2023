import java.util.*;
import java.util.stream.Collectors;

public class P01_RubberDuckDebuggers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> input = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).collect(Collectors.toList());
        ArrayDeque<Integer> programerTime = new ArrayDeque<>();
        for (int i = 0; i < input.size(); i++) {
            int element = input.get(i);
            programerTime.offer(element);
        }

        input = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).collect(Collectors.toList());
        ArrayDeque<Integer> numberOfTask = new ArrayDeque<>();
        for (int i = 0; i < input.size(); i++) {
            int element = input.get(i);
            numberOfTask.push(element);
        }
        int duckyDarkVaderCount = 0;
        int duckyThorCount = 0;
        int duckyBigBlueCount = 0;
        int duckySmallYellowCount = 0;

        Map<String, Integer> duckysRepo = new HashMap<>();
        duckysRepo.put("Darth Vader Ducky", 0);
        duckysRepo.put("Thor Ducky", 0);
        duckysRepo.put("Big Blue Rubber Ducky", 0);
        duckysRepo.put("Small Yellow Rubber Ducky", 0);

        while (!programerTime.isEmpty() || !numberOfTask.isEmpty()) {
            int multiplication = programerTime.peek() * numberOfTask.peek();
            if (multiplication >= 0 && multiplication <= 60) {
                duckyDarkVaderCount++;
                duckysRepo.put("Darth Vader Ducky", duckyDarkVaderCount);
                programerTime.poll();
                numberOfTask.pop();
            } else if (multiplication >= 61 && multiplication <= 120) {
                duckyThorCount++;
                duckysRepo.put("Thor Ducky", duckyThorCount);
                programerTime.poll();
                numberOfTask.pop();
            } else if (multiplication >= 121 && multiplication <= 180) {
                duckyBigBlueCount++;
                duckysRepo.put("Big Blue Rubber Ducky", duckyBigBlueCount);
                programerTime.poll();
                numberOfTask.pop();
            } else if (multiplication >= 181 && multiplication <= 240) {
                duckySmallYellowCount++;
                duckysRepo.put("Small Yellow Rubber Ducky", duckySmallYellowCount);
                programerTime.poll();
                numberOfTask.pop();
            } else if (multiplication > 240) {
                int current = numberOfTask.pop();
                numberOfTask.push(current - 2);
                int currentProgramerTime = programerTime.pop();
                programerTime.addLast(currentProgramerTime);
            }
        }

        System.out.println("Congratulations, all tasks have been completed! Rubber ducks rewarded:");
        System.out.printf("Darth Vader Ducky: %d%n" +
                        "Thor Ducky: %d%n" +
                        "Big Blue Rubber Ducky: %d%n" +
                        "Small Yellow Rubber Ducky: %d"
                , duckysRepo.get("Darth Vader Ducky")
                , duckysRepo.get("Thor Ducky")
                , duckysRepo.get("Big Blue Rubber Ducky")
                , duckysRepo.get("Small Yellow Rubber Ducky"));


    }

}

